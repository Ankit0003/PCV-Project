import { useState } from 'react';
import { BrowserRouter, Routes, Route, useNavigate } from 'react-router-dom';
import Header from './components/Header';
import VehicleTypeSelector from './components/VehicleTypeSelector';
import RegistrationForm from './components/RegistrationForm';
import VehicleDetails from './components/VehicleDetails';
import NewVehicleForm from './components/NewVehicleForm';
import OptionsMenu from './components/OptionsMenu';
import NavigationBar from './components/NavigationBar';
import PcvFinder from './components/PcvFinder/PcvFinder';
import QuestionnaireForm from './components/InsuranceQuestionnaire/QuestionnaireForm';
import ComprehensivePlans from './components/ComprehensivePlans/ComprehensivePlans';
import PolicyPurchase from './components/PolicyPurchase';
import VehicleDetailsPage from './components/PcvFinder/VehicleDetailsPage';

function MainApp() {
  const navigate = useNavigate();
  const [regNumber, setRegNumber] = useState('');
  const [vehicleType, setVehicleType] = useState<'renew' | 'new'>('renew');
  const [showPcvFinder, setShowPcvFinder] = useState(false);
  const [isNewVehicle, setIsNewVehicle] = useState(false);
  const [newVehicleData, setNewVehicleData] = useState({
    vehicleType: '',
    manufacturer: '',
    model: '',
    fuelType: '',
    variant: '',
    registrationYear: '',
    rto: ''
  });
  const [vehicleDetails, setVehicleDetails] = useState<any>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (vehicleType === 'renew') {
      if (vehicleDetails) {
        navigate('/vehicle-details', { 
          state: { 
            vehicleDetails
          }
        });
      } else {
        setVehicleDetails({
          manufacturer: "Bajaj",
          model: "RE Compact",
          manufacturingDate: "2004-01-01",
          registrationDate: "2004-05-10",
          registrationNo: regNumber || "MH43C4132",
          type: "2000/CNG",
          fuelType: "CNG"
        });
      }
    }
  };

  const handlePcvHelp = () => {
    setShowPcvFinder(true);
    setIsNewVehicle(vehicleType === 'new');
  };

  const handleBackFromPcv = () => {
    setShowPcvFinder(false);
    setIsNewVehicle(false);
  };

  const handleNewVehicleComplete = (data: typeof newVehicleData) => {
    setNewVehicleData(data);
    setShowPcvFinder(false);
    setIsNewVehicle(false);
  };

  if (showPcvFinder) {
    return (
      <PcvFinder 
        onBack={handleBackFromPcv} 
        isNewVehicle={isNewVehicle}
        onNewVehicleComplete={handleNewVehicleComplete}
      />
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-[#f0f7fa]">
      <Header title="PCV Insurance" onBack={() => navigate(-1)} />
      
      <main className="flex-1 container mx-auto max-w-md px-4 py-6">
        <VehicleTypeSelector
          selectedType={vehicleType}
          onTypeChange={setVehicleType}
        />
        
        {vehicleType === 'renew' ? (
          <>
            <RegistrationForm 
              regNumber={regNumber}
              setRegNumber={setRegNumber}
              onSubmit={handleSubmit}
              onPcvHelp={handlePcvHelp}
              vehicleDetails={vehicleDetails}
            />
            
            <div className="my-6 border-t border-gray-200"></div>
            
            <OptionsMenu />
          </>
        ) : (
          <NewVehicleForm 
            onSubmit={handleSubmit} 
            formData={newVehicleData}
            onVehicleTypeClick={handlePcvHelp}
          />
        )}
      </main>
      
      <NavigationBar />
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainApp />} />
        <Route path="/questionnaire" element={<QuestionnaireForm />} />
        <Route path="/vehicle-details" element={<VehicleDetailsPage />} />
        <Route path="/comprehensive-plans" element={<ComprehensivePlans />} />
        <Route path="/policy-purchase" element={<PolicyPurchase />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;