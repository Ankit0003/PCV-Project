import React, { useState, useEffect } from 'react';
import { X, Upload } from 'lucide-react';

interface OfflineQuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (formData: FormData) => void;
  preselectedInsurers: string[];
}

interface InsurerDetails {
  requiredAddOns: string[];
  preferredIdv: string;
}

interface FormData {
  vehicleType: string;
  vehicleSubType: string;
  vehicleUsageType: string;
  caseType: string;
  policyType: string;
  registrationNumber: string;
  make: string;
  model: string;
  fuelType: string;
  variant: string;
  registrationDate: string;
  manufacturingDate: string;
  rto: string;
  selectedInsurers: string[];
  insurerDetails: Record<string, InsurerDetails>;
  reason: string;
  rcFrontCopy: File | null;
  rcBackCopy: File | null;
  pypUpload: File | null;
  competitiveQuotes: File | null;
  additionalComments: string;
}

const OfflineQuoteModal = ({ isOpen, onClose, onSubmit, preselectedInsurers }: OfflineQuoteModalProps) => {
  const [formData, setFormData] = useState<FormData>({
    vehicleType: '',
    vehicleSubType: '',
    vehicleUsageType: '',
    caseType: '',
    policyType: '',
    registrationNumber: '',
    make: '',
    model: '',
    fuelType: '',
    variant: '',
    registrationDate: '',
    manufacturingDate: '',
    rto: '',
    selectedInsurers: preselectedInsurers,
    insurerDetails: {},
    reason: '',
    rcFrontCopy: null,
    rcBackCopy: null,
    pypUpload: null,
    competitiveQuotes: null,
    additionalComments: ''
  });

  const [showSuccessModal, setShowSuccessModal] = useState(false);

  useEffect(() => {
    setFormData(prev => ({
      ...prev,
      selectedInsurers: preselectedInsurers,
      insurerDetails: preselectedInsurers.reduce((acc, insurer) => ({
        ...acc,
        [insurer]: { requiredAddOns: [], preferredIdv: '' }
      }), {})
    }));
  }, [preselectedInsurers]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleInsurerSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedOptions = Array.from(e.target.selectedOptions).map(option => option.value);
    
    setFormData(prev => {
      const newInsurerDetails = { ...prev.insurerDetails };
      
      Object.keys(newInsurerDetails).forEach(insurer => {
        if (!selectedOptions.includes(insurer)) {
          delete newInsurerDetails[insurer];
        }
      });
      
      selectedOptions.forEach(insurer => {
        if (!newInsurerDetails[insurer]) {
          newInsurerDetails[insurer] = {
            requiredAddOns: [],
            preferredIdv: ''
          };
        }
      });
      
      return {
        ...prev,
        selectedInsurers: selectedOptions,
        insurerDetails: newInsurerDetails
      };
    });
  };

  const handleInsurerAddOns = (insurer: string, selectedAddOns: string[]) => {
    setFormData(prev => ({
      ...prev,
      insurerDetails: {
        ...prev.insurerDetails,
        [insurer]: {
          ...prev.insurerDetails[insurer],
          requiredAddOns: selectedAddOns
        }
      }
    }));
  };

  const handleInsurerIdv = (insurer: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      insurerDetails: {
        ...prev.insurerDetails,
        [insurer]: {
          ...prev.insurerDetails[insurer],
          preferredIdv: value
        }
      }
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, fieldName: keyof FormData) => {
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({ ...prev, [fieldName]: e.target.files![0] }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
    setShowSuccessModal(true);
  };

  if (!isOpen) return null;

  if (showSuccessModal) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end justify-center sm:items-center z-50">
        <div className="bg-white w-full max-w-md rounded-t-2xl sm:rounded-xl p-6 animate-slide-up">
          <div className="text-center mb-6">
            <h3 className="text-xl font-semibold text-gray-900">Success!</h3>
            <p className="mt-2 text-gray-600">
              Offline request raised successfully. Your ticket ID is 1PB1237
            </p>
          </div>
          <button
            onClick={() => {
              setShowSuccessModal(false);
              onClose();
            }}
            className="w-full bg-[#f94a56] text-white font-medium py-3 px-4 rounded-lg"
          >
            OK
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end justify-center sm:items-center z-50">
      <div className="bg-white w-full max-w-md rounded-t-2xl sm:rounded-xl overflow-hidden animate-slide-up">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-semibold text-gray-900">Offline Quote Request</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 max-h-[80vh] overflow-y-auto">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Vehicle Type</label>
              <select
                name="vehicleType"
                value={formData.vehicleType}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Select Vehicle Type</option>
                <option value="PCV">PCV</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Vehicle Sub Type</label>
              <select
                name="vehicleSubType"
                value={formData.vehicleSubType}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Select Sub Type</option>
                <option value="Bus">Bus</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Vehicle Usage Type</label>
              <select
                name="vehicleUsageType"
                value={formData.vehicleUsageType}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Select Usage Type</option>
                <option value="School Bus">School Bus</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Case Type</label>
              <select
                name="caseType"
                value={formData.caseType}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Select Case Type</option>
                <option value="Used">Used</option>
                <option value="New">New</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Policy Type</label>
              <select
                name="policyType"
                value={formData.policyType}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Select Policy Type</option>
                <option value="Comprehensive">Comprehensive</option>
                <option value="Third Party">Third Party</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Registration Number</label>
              <input
                type="text"
                name="registrationNumber"
                value={formData.registrationNumber}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Make</label>
              <input
                type="text"
                name="make"
                value={formData.make}
                onChange={handleInputChange}
                placeholder="e.g., Ashok Leyland"
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Model</label>
              <input
                type="text"
                name="model"
                value={formData.model}
                onChange={handleInputChange}
                placeholder="e.g., 12 FE"
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Fuel Type</label>
              <select
                name="fuelType"
                value={formData.fuelType}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Select Fuel Type</option>
                <option value="Diesel">Diesel</option>
                <option value="Petrol">Petrol</option>
                <option value="CNG">CNG</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Variant</label>
              <input
                type="text"
                name="variant"
                value={formData.variant}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Registration Date</label>
              <input
                type="date"
                name="registrationDate"
                value={formData.registrationDate}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Manufacturing Date</label>
              <input
                type="date"
                name="manufacturingDate"
                value={formData.manufacturingDate}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">RTO</label>
              <input
                type="text"
                name="rto"
                value={formData.rto}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Selected Insurers</label>
              <select
                multiple
                value={formData.selectedInsurers}
                onChange={handleInsurerSelect}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 h-32"
                required
              >
                <option value="United India">United India</option>
                <option value="ICICI Lombard">ICICI Lombard</option>
                <option value="SBI General">SBI General</option>
                <option value="Bajaj Allianz">Bajaj Allianz</option>
                <option value="HDFC ERGO">HDFC ERGO</option>
              </select>
              <p className="text-sm text-gray-500 mt-1">Hold Ctrl/Cmd to select multiple insurers</p>
            </div>

            {formData.selectedInsurers.map((insurer) => (
              <div key={insurer} className="border rounded-lg p-4 space-y-4">
                <h3 className="font-medium text-gray-900">{insurer}</h3>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Required Add-ons</label>
                  <select
                    multiple
                    value={formData.insurerDetails[insurer]?.requiredAddOns || []}
                    onChange={(e) => handleInsurerAddOns(insurer, Array.from(e.target.selectedOptions).map(opt => opt.value))}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 h-32"
                    required
                  >
                    <option value="Zero Depreciation">Zero Depreciation</option>
                    <option value="Engine Protection">Engine Protection</option>
                    <option value="NCB Protection">NCB Protection</option>
                    <option value="Return to Invoice">Return to Invoice</option>
                    <option value="Roadside Assistance">Roadside Assistance</option>
                    <option value="Consumables">Consumables</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Preferred IDV</label>
                  <input
                    type="number"
                    value={formData.insurerDetails[insurer]?.preferredIdv || ''}
                    onChange={(e) => handleInsurerIdv(insurer, e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
              </div>
            ))}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Reason for Offline Quote</label>
              <select
                name="reason"
                value={formData.reason}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="">Select Reason</option>
                <option value="Online quote not available">Online quote not available</option>
                <option value="Technical issue">Technical issue</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">RC Front Copy</label>
                <div className="relative border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-500 transition-colors">
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <p className="mt-2 text-sm text-gray-600">
                    {formData.rcFrontCopy ? formData.rcFrontCopy.name : 'Click to upload or drag and drop'}
                  </p>
                  <input
                    type="file"
                    onChange={(e) => handleFileChange(e, 'rcFrontCopy')}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">RC Back Copy</label>
                <div className="relative border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-500 transition-colors">
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <p className="mt-2 text-sm text-gray-600">
                    {formData.rcBackCopy ? formData.rcBackCopy.name : 'Click to upload or drag and drop'}
                  </p>
                  <input
                    type="file"
                    onChange={(e) => handleFileChange(e, 'rcBackCopy')}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">PYP Upload</label>
                <div className="relative border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-500 transition-colors">
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <p className="mt-2 text-sm text-gray-600">
                    {formData.pypUpload ? formData.pypUpload.name : 'Click to upload or drag and drop'}
                  </p>
                  <input
                    type="file"
                    onChange={(e) => handleFileChange(e, 'pypUpload')}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Competitive Quotes</label>
                <div className="relative border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-500 transition-colors">
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <p className="mt-2 text-sm text-gray-600">
                    {formData.competitiveQuotes ? formData.competitiveQuotes.name : 'Click to upload or drag and drop'}
                  </p>
                  <input
                    type="file"
                    onChange={(e) => handleFileChange(e, 'competitiveQuotes')}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    required
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Additional Comments</label>
              <textarea
                name="additionalComments"
                value={formData.additionalComments}
                onChange={handleInputChange}
                rows={4}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full mt-6 bg-[#f94a56] text-white font-medium py-3 px-4 rounded-lg"
          >
            Submit
          </button>
        </form>
      </div>
    </div>
  );
};

export default OfflineQuoteModal;