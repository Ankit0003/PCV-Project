import React, { useState } from 'react';
import { Search } from 'lucide-react';
import PolicyDetailsModal from './PolicyDetailsModal';

interface RtoStepProps {
  onSelect: (rto: string, needsInspection: boolean) => void;
  isNewVehicle?: boolean;
}

interface CityData {
  name: string;
  codes: string[];
}

const RtoStep = ({ onSelect, isNewVehicle }: RtoStepProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showPolicyModal, setShowPolicyModal] = useState(false);
  const [selectedRto, setSelectedRto] = useState('');

  const cities: CityData[] = [
    {
      name: 'New Delhi',
      codes: ['DL11', 'DL12', 'DL03', 'DL06', 'DL01', 'DL07', 'DL04', 'DL08', 'DL02', 'DL05', 'DL14', 'DL13', 'DL10', 'DL09', 'DL30', 'DL51', 'DL53']
    },
    {
      name: 'Ahmedabad',
      codes: ['GJ27', 'GJ01', 'GJ38']
    },
    {
      name: 'Bangalore',
      codes: ['KA59', 'KA52', 'KA61', 'KA01', 'KA04', 'KA60', 'KA05', 'KA50', 'KA57', 'KA53', 'KA02', 'KA51', 'KA03', 'KA41', 'KA10']
    },
    {
      name: 'Chandigarh',
      codes: ['CH04', 'CH03', 'PB01', 'CH02', 'HR70', 'CH01', 'CH02']
    }
  ];

  const filteredCities = cities.filter(city => 
    city.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    city.codes.some(code => code.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleRtoSelect = (rto: string) => {
    if (isNewVehicle) {
      onSelect(rto, false);
    } else {
      setSelectedRto(rto);
      setShowPolicyModal(true);
    }
  };

  const handlePolicyModalClose = () => {
    setShowPolicyModal(false);
  };

  const handlePolicyContinue = (needsInspection: boolean) => {
    onSelect(selectedRto, needsInspection);
    setShowPolicyModal(false);
  };

  return (
    <>
      <div className="space-y-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
            <Search size={20} className="text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search RTO/City"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-4 bg-white rounded-lg text-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-blue-400 shadow-sm border border-gray-100"
          />
        </div>

        <div className="space-y-8">
          {filteredCities.map((city) => (
            <div key={city.name} className="space-y-4">
              <h2 className="text-xl font-medium text-gray-800">{city.name}</h2>
              <div className="grid grid-cols-5 gap-3">
                {city.codes.map((code) => (
                  <button
                    key={code}
                    onClick={() => handleRtoSelect(code)}
                    className="bg-white rounded-full py-2 px-3 text-sm font-medium text-gray-700 hover:bg-gray-50 border border-gray-200 transition-colors duration-200 shadow-sm"
                  >
                    {code}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {!isNewVehicle && (
        <PolicyDetailsModal
          isOpen={showPolicyModal}
          onClose={handlePolicyModalClose}
          onContinue={handlePolicyContinue}
        />
      )}
    </>
  );
};

export default RtoStep;