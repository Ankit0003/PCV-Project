import React from 'react';
import { X } from 'lucide-react';

interface InspectionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const InspectionModal = ({ isOpen, onClose }: InspectionModalProps) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg w-full max-w-md">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-medium text-gray-800">Notice</h3>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <X size={24} />
            </button>
          </div>
          
          <p className="text-gray-700 text-lg mb-8 text-center">Inspection is needed</p>
          
          <button
            onClick={onClose}
            className="w-full bg-[#f94a56] hover:bg-[#e03840] text-white font-medium py-3 px-4 rounded-lg transition-colors duration-200"
          >
            OK
          </button>
        </div>
      </div>
    </div>
  );
};

export default InspectionModal