import React, { useState } from 'react';
import { ChevronRight, X, Upload } from 'lucide-react';

interface ModelStepProps {
  onSelect: (model: string) => void;
}

const ModelStep = ({ onSelect }: ModelStepProps) => {
  const [showRcUploadModal, setShowRcUploadModal] = useState(false);
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);
  const [rcFrontFile, setRcFrontFile] = useState<File | null>(null);
  const [rcBackFile, setRcBackFile] = useState<File | null>(null);
  const models = ['EECO', 'Omni'];

  const handleModelNotAvailable = () => {
    setShowRcUploadModal(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'front' | 'back') => {
    if (e.target.files && e.target.files[0]) {
      if (type === 'front') {
        setRcFrontFile(e.target.files[0]);
      } else {
        setRcBackFile(e.target.files[0]);
      }
    }
  };

  const handleSubmitRc = (e: React.FormEvent) => {
    e.preventDefault();
    setShowRcUploadModal(false);
    setShowConfirmationModal(true);
    // Reset files
    setRcFrontFile(null);
    setRcBackFile(null);
  };

  const handleCloseConfirmation = () => {
    setShowConfirmationModal(false);
  };

  const handleCloseUpload = () => {
    setShowRcUploadModal(false);
    setRcFrontFile(null);
    setRcBackFile(null);
  };

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100 mb-4">
        <input
          type="text"
          placeholder="Search model"
          className="w-full px-4 py-4 text-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
        />
      </div>

      <div className="flex items-center justify-between mb-2">
        <h2 className="text-lg font-medium text-gray-800">Model</h2>
        <button 
          onClick={handleModelNotAvailable}
          className="text-blue-500 text-sm hover:text-blue-600"
        >
          Model not available?
        </button>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm border border-gray-100 divide-y divide-gray-100">
        {models.map((model) => (
          <button
            key={model}
            onClick={() => onSelect(model)}
            className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors duration-200"
          >
            <span className="text-gray-800">{model}</span>
            <ChevronRight size={20} className="text-gray-400" />
          </button>
        ))}
      </div>

      {/* RC Upload Modal */}
      {showRcUploadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-md relative">
            <button
              onClick={handleCloseUpload}
              className="absolute right-4 top-4 text-gray-400 hover:text-gray-600"
              aria-label="Close modal"
            >
              <X size={24} />
            </button>
            
            <div className="p-6">
              <h3 className="text-xl font-medium text-gray-800 mb-6">Upload RC Copy</h3>
              
              <form onSubmit={handleSubmitRc} className="space-y-4">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">RC Front Copy</label>
                  <div className="relative border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-500 transition-colors cursor-pointer">
                    <Upload className="mx-auto h-12 w-12 text-gray-400" />
                    <p className="mt-2 text-sm text-gray-600">
                      {rcFrontFile ? rcFrontFile.name : 'Click to upload or drag and drop'}
                    </p>
                    <input 
                      type="file" 
                      onChange={(e) => handleFileChange(e, 'front')}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                      accept="image/*" 
                      required 
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">RC Back Copy</label>
                  <div className="relative border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-500 transition-colors cursor-pointer">
                    <Upload className="mx-auto h-12 w-12 text-gray-400" />
                    <p className="mt-2 text-sm text-gray-600">
                      {rcBackFile ? rcBackFile.name : 'Click to upload or drag and drop'}
                    </p>
                    <input 
                      type="file" 
                      onChange={(e) => handleFileChange(e, 'back')}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                      accept="image/*" 
                      required 
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#f94a56] hover:bg-[#e03840] text-white font-medium py-3 px-4 rounded-lg transition-colors duration-200"
                >
                  Submit
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {showConfirmationModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-md relative">
            <button
              onClick={handleCloseConfirmation}
              className="absolute right-4 top-4 text-gray-400 hover:text-gray-600"
              aria-label="Close modal"
            >
              <X size={24} />
            </button>
            
            <div className="p-6">
              <h3 className="text-xl font-medium text-gray-800 mb-4 text-center">Please check your model after 24 hours</h3>
              
              <button
                onClick={handleCloseConfirmation}
                className="w-full bg-[#f94a56] hover:bg-[#e03840] text-white font-medium py-3 px-4 rounded-lg transition-colors duration-200 mt-4"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ModelStep;