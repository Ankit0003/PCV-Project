import React from 'react';
import { ChevronRight } from 'lucide-react';

interface RegistrationYearStepProps {
  onSelect: (year: string) => void;
}

const RegistrationYearStep = ({ onSelect }: RegistrationYearStepProps) => {
  const years = ['2024', '2023', '2022', '2021'];

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100 mb-4">
        <input
          type="text"
          placeholder="Search year"
          className="w-full px-4 py-4 text-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
        />
      </div>

      <h2 className="text-lg font-medium text-gray-800 mb-2">Registration Year</h2>
      
      <div className="bg-white rounded-lg shadow-sm border border-gray-100 divide-y divide-gray-100">
        {years.map((year) => (
          <button
            key={year}
            onClick={() => onSelect(year)}
            className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors duration-200"
          >
            <span className="text-gray-800">{year}</span>
            <ChevronRight size={20} className="text-gray-400" />
          </button>
        ))}
      </div>
    </div>
  );
};

export default RegistrationYearStep;