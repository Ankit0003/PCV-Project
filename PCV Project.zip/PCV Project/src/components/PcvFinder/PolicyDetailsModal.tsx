import React, { useState } from 'react';
import { X, ChevronDown } from 'lucide-react';
import InspectionModal from './InspectionModal';
import { useNavigate } from 'react-router-dom';

interface PolicyDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onContinue: (needsInspection: boolean) => void;
}

const PolicyDetailsModal = ({ isOpen, onClose, onContinue }: PolicyDetailsModalProps) => {
  const navigate = useNavigate();
  const [policyType, setPolicyType] = useState<'OD+TP' | 'TP'>('OD+TP');
  const [isUsedCar, setIsUsedCar] = useState(false);
  const [knowsPreviousPolicy, setKnowsPreviousPolicy] = useState(true);
  const [previousPolicyType, setPreviousPolicyType] = useState<'OD+TP' | 'TP'>('OD+TP');
  const [expiredOver90Days, setExpiredOver90Days] = useState(false);
  const [expiryDate, setExpiryDate] = useState('');
  const [showInsurerDropdown, setShowInsurerDropdown] = useState(false);
  const [previousInsurer, setPreviousInsurer] = useState('');
  const [madeClaim, setMadeClaim] = useState(false);
  const [previousNcb, setPreviousNcb] = useState('0');
  const [showInspectionModal, setShowInspectionModal] = useState(false);

  const handleInsurerSelect = (insurer: string) => {
    setPreviousInsurer(insurer);
    setShowInsurerDropdown(false);
  };

  const handleContinue = () => {
    const needsInspection = policyType === 'OD+TP' && previousPolicyType === 'TP';
    
    if (needsInspection) {
      setShowInspectionModal(true);
    } else {
      navigate('/vehicle-details');
      onClose();
    }
  };

  const handleInspectionModalClose = () => {
    setShowInspectionModal(false);
    navigate('/vehicle-details');
    onClose();
  };

  return (
    <>
      <div className={`fixed inset-x-0 bottom-0 transform ${isOpen ? 'translate-y-0' : 'translate-y-full'} transition-transform duration-300 ease-in-out z-40`}>
        <div className="bg-white rounded-t-3xl max-h-[90vh] overflow-y-auto">
          <div className="p-6 space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-semibold text-gray-800">Previous year policy details</h2>
                <p className="text-gray-600 mt-1">Last step away to Compare quotes</p>
              </div>
              <button onClick={onClose} className="p-2">
                <X size={24} className="text-gray-400" />
              </button>
            </div>

            {/* Required Policy Type */}
            <div className="space-y-3">
              <p className="text-gray-700 font-medium">Required policy type?</p>
              <div className="flex gap-4">
                <button
                  onClick={() => setPolicyType('OD+TP')}
                  className={`flex-1 py-3 px-4 rounded-lg border ${policyType === 'OD+TP' ? 'border-blue-500 bg-blue-50 text-blue-600' : 'border-gray-200 text-gray-700'}`}
                >
                  OD+TP
                </button>
                <button
                  onClick={() => setPolicyType('TP')}
                  className={`flex-1 py-3 px-4 rounded-lg border ${policyType === 'TP' ? 'border-blue-500 bg-blue-50 text-blue-600' : 'border-gray-200 text-gray-700'}`}
                >
                  TP
                </button>
              </div>
            </div>

            {/* Used Car Toggle */}
            <div className="flex justify-between items-center">
              <span className="text-gray-700 font-medium">Used car or ownership transfer?</span>
              <button
                onClick={() => setIsUsedCar(!isUsedCar)}
                className={`w-14 h-8 rounded-full p-1 transition-colors duration-200 ${isUsedCar ? 'bg-green-500' : 'bg-gray-300'}`}
              >
                <div className={`w-6 h-6 bg-white rounded-full shadow-sm transform transition-transform duration-200 ${isUsedCar ? 'translate-x-6' : 'translate-x-0'}`} />
              </button>
            </div>

            {!isUsedCar && (
              <>
                {/* Previous Policy Knowledge Toggle */}
                <div className="flex justify-between items-center">
                  <span className="text-gray-700 font-medium">Do you know about your previous policy?</span>
                  <button
                    onClick={() => setKnowsPreviousPolicy(!knowsPreviousPolicy)}
                    className={`w-14 h-8 rounded-full p-1 transition-colors duration-200 ${knowsPreviousPolicy ? 'bg-green-500' : 'bg-gray-300'}`}
                  >
                    <div className={`w-6 h-6 bg-white rounded-full shadow-sm transform transition-transform duration-200 ${knowsPreviousPolicy ? 'translate-x-6' : 'translate-x-0'}`} />
                  </button>
                </div>

                {knowsPreviousPolicy && (
                  <>
                    {/* Previous Policy Type */}
                    <div className="space-y-3">
                      <p className="text-gray-700 font-medium">Previous policy type?</p>
                      <div className="flex gap-4">
                        <button
                          onClick={() => setPreviousPolicyType('OD+TP')}
                          className={`flex-1 py-3 px-4 rounded-lg border ${previousPolicyType === 'OD+TP' ? 'border-blue-500 bg-blue-50 text-blue-600' : 'border-gray-200 text-gray-700'}`}
                        >
                          OD+TP
                        </button>
                        <button
                          onClick={() => setPreviousPolicyType('TP')}
                          className={`flex-1 py-3 px-4 rounded-lg border ${previousPolicyType === 'TP' ? 'border-blue-500 bg-blue-50 text-blue-600' : 'border-gray-200 text-gray-700'}`}
                        >
                          TP
                        </button>
                      </div>
                    </div>

                    {/* Policy Expiry Toggle */}
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700 font-medium">Policy expired more than 90 days ago?</span>
                      <button
                        onClick={() => setExpiredOver90Days(!expiredOver90Days)}
                        className={`w-14 h-8 rounded-full p-1 transition-colors duration-200 ${expiredOver90Days ? 'bg-green-500' : 'bg-gray-300'}`}
                      >
                        <div className={`w-6 h-6 bg-white rounded-full shadow-sm transform transition-transform duration-200 ${expiredOver90Days ? 'translate-x-6' : 'translate-x-0'}`} />
                      </button>
                    </div>

                    {!expiredOver90Days && (
                      <>
                        {/* Expiry Date Input */}
                        <div className="space-y-2">
                          <input
                            type="date"
                            value={expiryDate}
                            onChange={(e) => setExpiryDate(e.target.value)}
                            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                            placeholder="Expiry Date"
                          />
                        </div>

                        {/* Previous Insurer Dropdown */}
                        <div className="space-y-2 relative">
                          <div
                            onClick={() => setShowInsurerDropdown(!showInsurerDropdown)}
                            className="w-full px-4 py-3 rounded-lg border border-gray-200 flex justify-between items-center cursor-pointer"
                          >
                            <span className={previousInsurer ? 'text-gray-900' : 'text-gray-400'}>
                              {previousInsurer || 'Select Previous Insurer'}
                            </span>
                            <ChevronDown size={20} className="text-gray-400" />
                          </div>
                          {showInsurerDropdown && (
                            <div className="absolute top-full left-0 right-0 bg-white border border-gray-200 rounded-lg mt-1 shadow-lg z-10">
                              <button
                                onClick={() => handleInsurerSelect('ICICI Lombard')}
                                className="w-full px-4 py-3 text-left hover:bg-gray-50"
                              >
                                ICICI Lombard
                              </button>
                            </div>
                          )}
                        </div>

                        {/* Claims Toggle */}
                        <div className="flex justify-between items-center">
                          <span className="text-gray-700 font-medium">Made any claim in existing policy?</span>
                          <button
                            onClick={() => setMadeClaim(!madeClaim)}
                            className={`w-14 h-8 rounded-full p-1 transition-colors duration-200 ${madeClaim ? 'bg-green-500' : 'bg-gray-300'}`}
                          >
                            <div className={`w-6 h-6 bg-white rounded-full shadow-sm transform transition-transform duration-200 ${madeClaim ? 'translate-x-6' : 'translate-x-0'}`} />
                          </button>
                        </div>

                        {!madeClaim && (
                          /* Previous NCB Selection */
                          <div className="space-y-3">
                            <p className="text-gray-700 font-medium">Previous year NCB</p>
                            <div className="flex gap-2 overflow-x-auto pb-2">
                              {['0', '20', '25', '35', '45', '50'].map((ncb) => (
                                <button
                                  key={ncb}
                                  onClick={() => setPreviousNcb(ncb)}
                                  className={`py-2 px-4 rounded-full border whitespace-nowrap ${
                                    previousNcb === ncb
                                      ? 'border-blue-500 bg-blue-50 text-blue-600'
                                      : 'border-gray-200 text-gray-700'
                                  }`}
                                >
                                  {ncb}%
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </>
                )}
              </>
            )}

            {/* Continue Button */}
            <button
              onClick={handleContinue}
              className="w-full bg-[#f94a56] text-white font-medium py-4 px-4 rounded-lg hover:bg-[#e03840] transition-colors duration-200"
            >
              Continue
            </button>
          </div>
        </div>
      </div>

      <InspectionModal 
        isOpen={showInspectionModal}
        onClose={handleInspectionModalClose}
      />
    </>
  );
};

export default PolicyDetailsModal;