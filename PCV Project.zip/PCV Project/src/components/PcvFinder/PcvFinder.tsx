import React, { useState } from 'react';
import VehicleTypeStep from './VehicleTypeStep';
import ManufacturerStep from './ManufacturerStep';
import ModelStep from './ModelStep';
import FuelTypeStep from './FuelTypeStep';
import VariantStep from './VariantStep';
import RegistrationYearStep from './RegistrationYearStep';
import RtoStep from './RtoStep';
import VehicleDetailsPage from './VehicleDetailsPage';
import Header from '../Header';

type Step = 'vehicle-type' | 'manufacturer' | 'model' | 'fuel-type' | 'variant' | 'registration-year' | 'rto' | 'vehicle-details';

interface PcvFinderProps {
  onBack?: () => void;
  isNewVehicle?: boolean;
  onNewVehicleComplete?: (data: {
    vehicleType: string;
    manufacturer: string;
    model: string;
    fuelType: string;
    variant: string;
    registrationYear: string;
    rto: string;
  }) => void;
}

const PcvFinder = ({ onBack, isNewVehicle, onNewVehicleComplete }: PcvFinderProps) => {
  const [currentStep, setCurrentStep] = useState<Step>('vehicle-type');
  const [selections, setSelections] = useState({
    vehicleType: '',
    manufacturer: '',
    model: '',
    fuelType: '',
    variant: '',
    registrationYear: '',
    rto: '',
  });

  const getStepTitle = () => {
    switch (currentStep) {
      case 'vehicle-type':
        return 'Find your PCV';
      case 'manufacturer':
        return 'Find your PCV';
      case 'model':
        return 'Find your PCV';
      case 'fuel-type':
        return 'Find your PCV';
      case 'variant':
        return 'Find your PCV';
      case 'registration-year':
        return 'Find your PCV';
      case 'rto':
        return 'RTO/City';
      default:
        return 'Find your PCV';
    }
  };

  const handleBack = () => {
    if (currentStep === 'vehicle-type') {
      onBack?.();
      return;
    }

    switch (currentStep) {
      case 'manufacturer':
        setCurrentStep('vehicle-type');
        break;
      case 'model':
        setCurrentStep('manufacturer');
        break;
      case 'fuel-type':
        setCurrentStep('model');
        break;
      case 'variant':
        setCurrentStep('fuel-type');
        break;
      case 'registration-year':
        setCurrentStep('variant');
        break;
      case 'rto':
        setCurrentStep('registration-year');
        break;
      case 'vehicle-details':
        setCurrentStep('rto');
        break;
      default:
        break;
    }
  };

  const handleVehicleTypeSelect = (type: string) => {
    setSelections({ ...selections, vehicleType: type });
    setCurrentStep('manufacturer');
  };

  const handleManufacturerSelect = (manufacturer: string) => {
    setSelections({ ...selections, manufacturer });
    setCurrentStep('model');
  };

  const handleModelSelect = (model: string) => {
    setSelections({ ...selections, model });
    setCurrentStep('fuel-type');
  };

  const handleFuelTypeSelect = (fuelType: string) => {
    setSelections({ ...selections, fuelType });
    setCurrentStep('variant');
  };

  const handleVariantSelect = (variant: string) => {
    setSelections({ ...selections, variant });
    setCurrentStep('registration-year');
  };

  const handleRegistrationYearSelect = (year: string) => {
    setSelections({ ...selections, registrationYear: year });
    setCurrentStep('rto');
  };

  const handleRtoSelect = (rto: string, needsInspection: boolean) => {
    const updatedSelections = { ...selections, rto };
    setSelections(updatedSelections);
    
    if (isNewVehicle && onNewVehicleComplete) {
      onNewVehicleComplete(updatedSelections);
    } else {
      setCurrentStep('vehicle-details');
    }
  };

  if (currentStep === 'vehicle-details') {
    return (
      <VehicleDetailsPage
        manufacturer={selections.manufacturer}
        model={selections.model}
        onBack={handleBack}
      />
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-[#f0f7fa]">
      <Header title={getStepTitle()} onBack={handleBack} />
      
      <main className="flex-1 container mx-auto max-w-md px-4 py-6">
        {currentStep === 'vehicle-type' && (
          <VehicleTypeStep onSelect={handleVehicleTypeSelect} />
        )}
        {currentStep === 'manufacturer' && (
          <ManufacturerStep onSelect={handleManufacturerSelect} />
        )}
        {currentStep === 'model' && (
          <ModelStep onSelect={handleModelSelect} />
        )}
        {currentStep === 'fuel-type' && (
          <FuelTypeStep onSelect={handleFuelTypeSelect} />
        )}
        {currentStep === 'variant' && (
          <VariantStep onSelect={handleVariantSelect} />
        )}
        {currentStep === 'registration-year' && (
          <RegistrationYearStep onSelect={handleRegistrationYearSelect} />
        )}
        {currentStep === 'rto' && (
          <RtoStep onSelect={handleRtoSelect} isNewVehicle={isNewVehicle} />
        )}
      </main>
    </div>
  );
};

export default PcvFinder;