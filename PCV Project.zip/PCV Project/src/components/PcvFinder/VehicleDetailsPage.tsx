import React, { useState } from 'react';
import { Star, Share2, Info, ChevronRight, Coins, X, HelpCircle } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import jsPDF from 'jspdf';
import Header from '../Header';
import OfflineQuoteModal from '../OfflineQuoteModal';
import QueryModal from '../QueryModal';
import IdvModal from '../IdvModal';
import SortFilterModal from '../SortFilterModal';
import EditVehicleModal from './EditVehicleModal';

interface VehicleDetailsPageProps {
  onBack?: () => void;
}

interface InsuranceQuote {
  company: string;
  premium?: number;
  basicOwnDetails?: number;
  discount: number;
  idv: number;
  coverPeriod: string;
  inspectionRequired?: boolean;
  addons: {
    available: number;
    total: number;
    cost: number;
  };
  additionalFeatures: Array<{
    name: string;
    cost?: number;
    included?: boolean;
  }>;
}

const VehicleDetailsPage = ({ onBack }: VehicleDetailsPageProps) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [policyType, setPolicyType] = useState<'comprehensive' | 'third-party'>('comprehensive');
  const [showEarnings, setShowEarnings] = useState(true);
  const [showCompareModal, setShowCompareModal] = useState(false);
  const [selectedQuotes, setSelectedQuotes] = useState<number[]>([]);
  const [sharedQuotes, setSharedQuotes] = useState<number[]>([]);
  const [showOfflineQuoteModal, setShowOfflineQuoteModal] = useState(false);
  const [showQueryModal, setShowQueryModal] = useState(false);
  const [selectedOfflineQuotes, setSelectedOfflineQuotes] = useState<string[]>([]);
  const [showIdvModal, setShowIdvModal] = useState(false);
  const [showSortFilterModal, setShowSortFilterModal] = useState(false);
  const [mode, setMode] = useState<'none' | 'compare' | 'share'>('none');
  const [showEditModal, setShowEditModal] = useState(false);

  const { vehicleDetails } = location.state || {
    vehicleDetails: {
      manufacturer: "Bajaj",
      model: "RE Compact",
      manufacturingDate: "2004-01-01",
      registrationDate: "2004-05-10",
      registrationNo: "MH43C4132",
      type: "2000/CNG",
      fuelType: "CNG"
    }
  };

  const insuranceQuotes: InsuranceQuote[] = [
    {
      company: 'United India',
      basicOwnDetails: 3812,
      discount: 69,
      idv: 121108,
      coverPeriod: '1 year',
      inspectionRequired: true,
      addons: {
        available: 3,
        total: 5,
        cost: 432
      },
      additionalFeatures: [
        { name: 'Zero dep cover', included: false },
        { name: 'Consumables', cost: 94 },
        { name: 'Engine Gear Box Cover', cost: 229 },
        { name: 'NCB Protection', included: false },
        { name: 'Road Side Assistance', cost: 109 }
      ]
    },
    {
      company: 'IFFCO Tokio',
      basicOwnDetails: 4250,
      discount: 75,
      idv: 124000,
      coverPeriod: '1 year',
      inspectionRequired: true,
      addons: {
        available: 4,
        total: 6,
        cost: 525
      },
      additionalFeatures: [
        { name: 'Zero dep cover', cost: 195 },
        { name: 'Consumables', included: true },
        { name: 'Engine Gear Box Cover', cost: 255 },
        { name: 'NCB Protection', cost: 175 },
        { name: 'Road Side Assistance', included: true },
        { name: 'Return to Invoice', cost: 285 }
      ]
    },
    {
      company: 'Bajaj Allianz',
      basicOwnDetails: 4125,
      discount: 73,
      idv: 123500,
      coverPeriod: '1 year',
      inspectionRequired: true,
      addons: {
        available: 4,
        total: 6,
        cost: 495
      },
      additionalFeatures: [
        { name: 'Zero dep cover', cost: 185 },
        { name: 'Consumables', included: true },
        { name: 'Engine Gear Box Cover', cost: 245 },
        { name: 'NCB Protection', included: true },
        { name: 'Road Side Assistance', cost: 65 },
        { name: 'Return to Invoice', cost: 275 }
      ]
    },
    {
      company: 'ICICI Lombard',
      basicOwnDetails: 3975,
      discount: 71,
      idv: 122750,
      coverPeriod: '1 year',
      inspectionRequired: true,
      addons: {
        available: 5,
        total: 7,
        cost: 515
      },
      additionalFeatures: [
        { name: 'Zero dep cover', cost: 165 },
        { name: 'Consumables', cost: 85 },
        { name: 'Engine Gear Box Cover', included: true },
        { name: 'NCB Protection', cost: 155 },
        { name: 'Road Side Assistance', included: true },
        { name: 'Return to Invoice', cost: 295 },
        { name: 'Key Replacement', cost: 75 }
      ]
    }
  ];

  const handleCompareToggle = (index: number) => {
    if (mode === 'share') return;
    
    setSelectedQuotes(prev => {
      const newSelected = prev.includes(index)
        ? prev.filter(i => i !== index)
        : [...prev, index];
      
      setShowCompareModal(newSelected.length > 0);
      setMode(newSelected.length > 0 ? 'compare' : 'none');
      return newSelected;
    });
  };

  const handleShareToggle = (index: number) => {
    if (mode === 'compare') return;
    
    setSharedQuotes(prev => {
      const newShared = prev.includes(index)
        ? prev.filter(i => i !== index)
        : [...prev, index];
      setMode(newShared.length > 0 ? 'share' : 'none');
      return newShared;
    });
  };

  const handleOfflineQuoteSubmit = (formData: any) => {
    console.log('Offline quote form data:', formData);
  };

  const handleOfflineQuoteSelect = (companyName: string) => {
    setSelectedOfflineQuotes(prev => 
      prev.includes(companyName)
        ? prev.filter(name => name !== companyName)
        : [...prev, companyName]
    );
  };

  const handleIdvSubmit = (idvType: string, customIdv?: number) => {
    console.log('Selected IDV type:', idvType, 'Custom IDV:', customIdv);
  };

  const handleSortFilterApply = (sortOption: string) => {
    console.log('Applying sort option:', sortOption);
  };

  const handleEditSave = (data: any) => {
    console.log('Updated vehicle details:', data);
  };

  const generatePDF = (compareData: InsuranceQuote[]) => {
    const pdf = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: 'a4'
    });
    
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 15;
    const startX = margin;
    const labelWidth = 60;
    const colWidth = (pageWidth - margin * 2 - labelWidth) / compareData.length;
    const rowHeight = 7;
    let yPos = margin;

    // Title
    pdf.setFontSize(18);
    pdf.setTextColor(33, 33, 33);
    pdf.text('Insurance Quote Comparison', pageWidth / 2, yPos, { align: 'center' });
    yPos += 15;

    // Calculate center positions for both columns
    const columnWidth = (pageWidth - (2 * margin)) / 2;
    const leftColumnCenter = margin + (columnWidth / 2);
    const rightColumnCenter = margin + columnWidth + (columnWidth / 2);
    
    // Section Headers - Centered
    pdf.setFontSize(14);
    pdf.setTextColor(51, 51, 51);
    pdf.text('Vehicle Details', leftColumnCenter, yPos, { align: 'center' });
    pdf.text('Basic details of vehicle', rightColumnCenter, yPos, { align: 'center' });
    yPos += 8;

    const vehicleDetails = [
      ['Vehicle type:', 'School bus'],
      ['Make and model:', 'Ashok Leyland 1/17 39-47 43+1D'],
      ['Policy due date:', '9 May 2026'],
      ['RTO location:', 'MH43- Navi Mumbai']
    ];

    const basicDetails = [
      ['Age of vehicle:', '3 years'],
      ['Seating capacity:', '44'],
      ['Registration year:', '2021']
    ];

    // Calculate maximum rows for alignment
    const maxRows = Math.max(vehicleDetails.length, basicDetails.length);
    
    // Calculate the widest label for each column to ensure proper alignment
    const getTextWidth = (text: string) => pdf.getTextWidth(text);
    
    const leftColumnMaxWidth = Math.max(...vehicleDetails.map(item => getTextWidth(item[0] + ' ' + item[1])));
    const rightColumnMaxWidth = Math.max(...basicDetails.map(item => getTextWidth(item[0] + ' ' + item[1])));
    
    // Calculate starting positions for centered text
    const leftTextStart = leftColumnCenter - (leftColumnMaxWidth / 2);
    const rightTextStart = rightColumnCenter - (rightColumnMaxWidth / 2);

    pdf.setFontSize(11);
    for (let i = 0; i < maxRows; i++) {
      if (i < vehicleDetails.length) {
        const text = `${vehicleDetails[i][0]} ${vehicleDetails[i][1]}`;
        pdf.text(text, leftColumnCenter, yPos, { align: 'center' });
      }
      if (i < basicDetails.length) {
        const text = `${basicDetails[i][0]} ${basicDetails[i][1]}`;
        pdf.text(text, rightColumnCenter, yPos, { align: 'center' });
      }
      yPos += 6;
    }

    yPos += 10;

    // Business Partner Details in center
    pdf.setFontSize(14);
    pdf.text('Business Partner Details', pageWidth / 2, yPos, { align: 'center' });
    yPos += 8;

    // Single line for partner details
    pdf.setFontSize(11);
    const partnerInfo = 'Ayush Mittal | Contact: 9799044384 | Email: ayush@gmail.com';
    pdf.text(partnerInfo, pageWidth / 2, yPos, { align: 'center' });
    yPos += 15;

    // Draw company headers
    let xPos = startX + labelWidth;
    pdf.setFontSize(12);
    pdf.setFont(undefined, 'bold');
    compareData.forEach(quote => {
      pdf.text(quote.company, xPos + colWidth / 2, yPos, { align: 'center' });
      xPos += colWidth;
    });
    yPos += rowHeight * 2;

    const sections = [
      {
        title: 'Own Damage Premium',
        rows: [
          ['IDV of the vehicle', '121108', '124000', '123500', '122750'],
          ['Basic Own Damage', '25000', '27500', '26800', '26200'],
          ['Electrical accessories', '1500', '1800', '1750', '1650'],
          ['Non electrical accessories', '1000', '1200', '1150', '1100'],
          ['Total OD premium without discounts', '27500', '30500', '29700', '28950'],
          ['NCB discount', '2750', '3050', '2970', '2895'],
          ['Own damage discount', '1375', '1525', '1485', '1447'],
          ['Net OD Premium (A)', '23375', '25925', '25245', '24608']
        ]
      },
      {
        title: 'Third Party Premium',
        rows: [
          ['Basic TP Premium', '7897', '8200', '8100', '8050'],
          ['PA cover', '1000', '1200', '1150', '1100'],
          ['Liability to paid driver', '500', '600', '550', '525'],
          ['PA cover to passenger', '1500', '1800', '1750', '1650'],
          ['Total TP Premium without discounts', '10897', '11800', '11550', '11325'],
          ['Net TP Premium (B)', '10897', '11800', '11550', '11325']
        ]
      },
      {
        title: 'Add-on Premium',
        rows: [
          ['Zero depreciation', '2500', '2800', '2750', '2650'],
          ['Consumables', '94', '110', '105', '85'],
          ['Engine Gear Box Cover', '229', '255', '245', '235'],
          ['Road side assistance', '109', '125', '120', '115'],
          ['Key & Lock replacement', '500', '550', '525', '515'],
          ['Tyre protection', '750', '850', '825', '800'],
          ['Loss of personal belongings', '250', '275', '265', '260'],
          ['Total add-on premium without discounts', '4432', '4965', '4835', '4660'],
          ['Net add on premium (C)', '4432', '4965', '4835', '4660']
        ]
      },
      {
        title: 'Final Premium',
        rows: [
          ['Total premium (A+B+C)', '38704', '42690', '41630', '40593'],
          ['GST (18%)', '6967', '7684', '7493', '7307'],
          ['Payable amount', '45671', '50374', '49123', '47900']
        ]
      }
    ];

    sections.forEach((section, sectionIndex) => {
      const sectionHeight = (section.rows.length + 2) * rowHeight;
      if (yPos + sectionHeight > pageHeight - margin) {
        pdf.addPage('landscape');
        yPos = margin;
        
        // Redraw company headers on new page
        let xPos = startX + labelWidth;
        pdf.setFontSize(12);
        pdf.setFont(undefined, 'bold');
        compareData.forEach(quote => {
          pdf.text(quote.company, xPos + colWidth / 2, yPos, { align: 'center' });
          xPos += colWidth;
        });
        yPos += rowHeight * 2;
      }

      pdf.setFontSize(12);
      pdf.setFont(undefined, 'bold');
      pdf.text(section.title, startX, yPos);
      yPos += rowHeight * 1.5;

      section.rows.forEach((row, index) => {
        const isBold = row[0].includes('Total') || row[0].includes('Net') || row[0].includes('Payable');
        pdf.setFontSize(isBold ? 11 : 10);
        pdf.setFont(undefined, isBold ? 'bold' : 'normal');

        pdf.text(row[0].toString(), startX, yPos);

        let xPos = startX + labelWidth;
        compareData.forEach((_, i) => {
          const value = row[i + 1] ? row[i + 1].toString() : '';
          pdf.text(value, xPos + colWidth / 2, yPos, { align: 'center' });
          xPos += colWidth;
        });
        yPos += rowHeight;
      });
      yPos += rowHeight * 1.5;
    });

    // Add tags section
    yPos += 10;
    pdf.setFontSize(11);
    pdf.setFont(undefined, 'bold');
    pdf.setTextColor(51, 51, 51);

    const tags = [
      { label: 'Lowest premium', company: 'United India' },
      { label: 'Highest IDV', company: 'IFFCO Tokio' },
      { label: 'Best discount', company: 'Bajaj Allianz' },
      { label: 'Most add ons offered', company: 'ICICI Lombard' }
    ];

    tags.forEach((tag, index) => {
      // Set font to bold for the label
  pdf.setFont(undefined, 'bold');
  pdf.text(tag.label + ':', startX, yPos);
  
  // Calculate width of the bold label
  const labelWidth = pdf.getTextWidth(tag.label + ': ');
  
  // Set font back to normal for the company name
  pdf.setFont(undefined, 'normal');
  pdf.text(tag.company, startX + labelWidth, yPos);
  
  yPos += 7;
    });
    
    pdf.setFont(undefined, 'normal');
    yPos += 10;
    pdf.setTextColor(0, 0, 255);
    pdf.textWithLink(
      'Still confused which policy to buy?',
      startX,
      yPos,
      { url: `${window.location.origin}/questionnaire` }
    );
    
    yPos += 10;
    pdf.textWithLink(
      'Want to purchase the policy?',
      startX,
      yPos,
      { url: `${window.location.origin}/policy-purchase` }
    );

    pdf.save('insurance-comparison.pdf');
  };

  const handleCompare = () => {
    const compareData = selectedQuotes.map(index => insuranceQuotes[index]);
    generatePDF(compareData);
    setShowCompareModal(false);
    setSelectedQuotes([]);
    setMode('none');
  };

  const offlineQuoteCompanies = [
    { name: 'United India' },
    { name: 'ICICI Lombard' },
    { name: 'SBI General' }
  ];

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="container mx-auto max-w-md px-4">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center">
              <button 
                onClick={() => navigate(-1)}
                className="mr-3 p-1 rounded-full hover:bg-gray-100"
              >
                <ChevronRight size={24} className="transform rotate-180" />
              </button>
              <h1 className="text-xl font-semibold">{vehicleDetails.manufacturer} {vehicleDetails.model}</h1>
            </div>
            <button 
              onClick={() => setShowEditModal(true)}
              className="text-blue-500 font-medium"
            >
              Edit
            </button>
          </div>
          
          <div className="flex">
            <button
              onClick={() => setPolicyType('comprehensive')}
              className={`flex-1 py-4 text-center font-medium border-b-2 ${
                policyType === 'comprehensive' 
                  ? 'text-blue-500 border-blue-500' 
                  : 'text-gray-500 border-transparent'
              }`}
            >
              Comprehensive
            </button>
            <button
              onClick={() => setPolicyType('third-party')}
              className={`flex-1 py-4 text-center font-medium border-b-2 ${
                policyType === 'third-party' 
                  ? 'text-blue-500 border-blue-500' 
                  : 'text-gray-500 border-transparent'
              }`}
            >
              Third Party
            </button>
          </div>
        </div>
      </div>

      <main className="flex-1">
        <div className="container mx-auto max-w-md px-4 py-4 pb-20">
          <div className="bg-orange-50 rounded-lg p-4 mb-4 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Star className="text-gray-700" size={20} />
              <span className="text-gray-800">Show Earnings on Quote</span>
            </div>
            <button
              onClick={() => setShowEarnings(!showEarnings)}
              className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 ${
                showEarnings ? 'bg-blue-500' : 'bg-gray-300'
              }`}
            >
              <div className={`w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform duration-200 ${
                showEarnings ? 'translate-x-6' : 'translate-x-0'
              }`} />
            </button>
          </div>

          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-medium text-gray-800">
              {policyType === 'comprehensive' ? '10 Comprehensive Plans' : '10 Third Party Plans'}
            </h2>
            <button className="flex items-center text-gray-600 space-x-1 px-3 py-1 border border-gray-300 rounded-lg">
              <Share2 size={16} />
              <span className="text-sm">Share All Quotes</span>
            </button>
          </div>

          {insuranceQuotes.map((quote, index) => (
            <div key={index} className="bg-white rounded-lg p-4 shadow-sm border border-gray-200 mb-4">
              <div className="flex justify-between items-start mb-4">
                <div className="text-sm text-gray-600">
                  Inspection required
                </div>
                {showEarnings && (
                  <div className="bg-green-50 px-3 py-1 rounded-lg flex items-center space-x-1">
                    <Coins size={16} className="text-green-700" />
                    <span className="text-green-700 font-medium">1817</span>
                  </div>
                )}
              </div>

              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center text-white text-xs">
                    LOGO
                  </div>
                  <span className="font-medium">{quote.company}</span>
                </div>
                <button 
                  //onClick={() => navigate('/policy-purchase')}
                  className="bg-white border border-gray-200 rounded-lg px-4 py-2 flex items-center space-x-2"
                >
                  <span className="font-medium">₹{quote.premium || quote.basicOwnDetails}</span>
                  <ChevronRight size={16} />
                </button>
              </div>

              {policyType === 'comprehensive' && (
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div>
                    <div className="text-sm text-gray-600">Discount</div>
                    <div className="font-medium">{quote.discount}%</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600">IDV</div>
                    <div className="font-medium">{quote.idv}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-600">Cover</div>
                    <div className="font-medium">{quote.coverPeriod}</div>
                  </div>
                </div>
              )}

              <div className="text-sm text-gray-600 mb-2">
                {quote.addons.available}/{quote.addons.total} Addons available (Rs. {quote.addons.cost})
              </div>
              
              <div className="space-y-1">
                {quote.additionalFeatures.map((feature, idx) => (
                  <div key={idx} className="text-sm text-gray-600">
                    {feature.name} {feature.included === false ? '- Not included' : feature.cost ? `(Rs. ${feature.cost})` : ''}
                  </div>
                ))}
              </div>

              <div className="mt-4 flex justify-between items-start">
                <button className="text-blue-500 text-sm">View benefits and break up</button>
                <div className="flex flex-col items-end space-y-2">
                  <label className={`flex items-center space-x-2 ${mode === 'compare' ? 'opacity-50 cursor-not-allowed' : ''}`}>
                    <input 
                      type="checkbox"
                      checked={sharedQuotes.includes(index)}
                      onChange={() => handleShareToggle(index)}
                      className="w-4 h-4"
                      disabled={mode === 'compare'}
                    />
                    <span className="text-sm text-gray-600">Add to share</span>
                  </label>
                  {policyType === 'comprehensive' && (
                    <label className={`flex items-center space-x-2 ${mode === 'share' ? 'opacity-50 cursor-not-allowed' : ''}`}>
                      <input 
                        type="checkbox"
                        checked={selectedQuotes.includes(index)}
                        onChange={() => handleCompareToggle(index)}
                        className="w-4 h-4"
                        disabled={mode === 'share'}
                      />
                      <span className="text-sm text-gray-600">Add to compare</span>
                    </label>
                  )}
                </div>
              </div>
            </div>
          ))}

          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200 mb-4">
            <h3 className="text-lg font-medium text-gray-800 mb-4">Want to request quotations offline?</h3>
            
            {offlineQuoteCompanies.map((company, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 border border-gray-200 rounded-lg mb-4">
                <input 
                  type="checkbox" 
                  checked={selectedOfflineQuotes.includes(company.name)}
                  onChange={() => handleOfflineQuoteSelect(company.name)}
                  className="mt-1 w-4 h-4" 
                />
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center text-white text-xs">
                      LOGO
                    </div>
                    <span className="font-medium">{company.name}</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Reason: The policy has been declined by the insurer.
                  </p>
                </div>
              </div>
            ))}

            <button 
              onClick={() => setShowOfflineQuoteModal(true)}
              className="w-full bg-white border border-gray-300 text-gray-800 font-medium py-2 px-4 rounded-lg hover:bg-gray-50 transition-colors duration-200"
            >
              SUBMIT
            </button>
          </div>

          <button
            onClick={() => setShowQueryModal(true)}
            className="fixed bottom-20 right-4 w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white shadow-lg hover:bg-blue-600 transition-colors duration-200"
          >
            <HelpCircle size={24} />
          </button>

          <QueryModal
            isOpen={showQueryModal}
            onClose={() => setShowQueryModal(false)}
          />

          {!showCompareModal && (
            <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-3">
              <div className="container mx-auto max-w-md px-4 flex justify-around">
                <button className="text-gray-600 flex items-center space-x-1">
                  <span>Score Chart</span>
                  <ChevronRight size={16} className="transform rotate-90" />
                </button>
                <div className="w-px bg-gray-200" />
                <button 
                  onClick={() => setShowIdvModal(true)} 
                  className="text-gray-600 flex items-center space-x-1"
                >
                  <span>IDV</span>
                  <ChevronRight size={16} className="transform rotate-90" />
                </button>
                <div className="w-px bg-gray-200" />
                <button 
                  onClick={() => setShowSortFilterModal(true)}
                  className="text-gray-600 flex items-center space-x-1"
                >
                  <span>Sort & Filter</span>
                </button>
              </div>
            </div>
          )}

          {showCompareModal && (
            <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-4 px-4 shadow-lg">
              <div className="container mx-auto max-w-md">
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center space-x-2">
                    <span className="font-medium">Compare ({selectedQuotes.length})</span>
                  </div>
                  <button 
                    onClick={() => {
                      setShowCompareModal(false);
                      setSelectedQuotes([]);
                      setMode('none');
                    }}
                    className="text-gray-500"
                  >
                    <X size={20} />
                  </button>
                </div>
                <div className="flex space-x-4">
                  <button
                    onClick={() => {
                      setShowCompareModal(false);
                      setSelectedQuotes([]);
                      setMode('none');
                    }}
                    className="flex-1 py-3 px-4 rounded-lg border border-gray-300 text-gray-700 font-medium"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleCompare}
                    className="flex-1 py-3 px-4 rounded-lg bg-blue-500 text-white font-medium"
                  >
                    Compare
                  </button>
                </div>
              </div>
            </div>
          )}

          <OfflineQuoteModal
            isOpen={showOfflineQuoteModal}
            onClose={() => setShowOfflineQuoteModal(false)}
            onSubmit={handleOfflineQuoteSubmit}
            preselectedInsurers={selectedOfflineQuotes}
          />

          <IdvModal
            isOpen={showIdvModal}
            onClose={() => setShowIdvModal(false)}
            onSubmit={handleIdvSubmit}
          />

          <SortFilterModal
            isOpen={showSortFilterModal}
            onClose={() => setShowSortFilterModal(false)}
            onApply={handleSortFilterApply}
          />

          <EditVehicleModal
            isOpen={showEditModal}
            onClose={() => setShowEditModal(false)}
            onSave={handleEditSave}
            initialData={vehicleDetails}
          />
        </div>
      </main>
    </div>
  );
};

export default VehicleDetailsPage;