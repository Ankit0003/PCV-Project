import React, { useState } from 'react';
import { X } from 'lucide-react';

interface IdvModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (idvType: string, customIdv?: number) => void;
}

const IdvModal = ({ isOpen, onClose, onSubmit }: IdvModalProps) => {
  const [selectedOption, setSelectedOption] = useState<string>('');
  const [customIdv, setCustomIdv] = useState<string>('');

  const handleSubmit = () => {
    onSubmit(selectedOption, selectedOption === 'custom' ? Number(customIdv) : undefined);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end justify-center z-50">
      <div className="bg-white w-full max-w-md rounded-t-2xl overflow-hidden animate-slide-up">
        <div className="p-4 border-b">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-900">Insured Declared Value (IDV)</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <X size={24} />
            </button>
          </div>
          <p className="mt-2 text-sm text-gray-600">
            IDV is the maximum sum insured fixed by the insurer.
          </p>
        </div>

        <div className="p-4 space-y-4">
          <label className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
            <input
              type="radio"
              name="idvOption"
              value="highest"
              checked={selectedOption === 'highest'}
              onChange={(e) => setSelectedOption(e.target.value)}
              className="w-4 h-4 text-blue-500"
            />
            <div className="ml-3">
              <span className="font-medium text-gray-900">Highest Value</span>
              <p className="text-sm text-gray-500">Maximum coverage for your vehicle</p>
            </div>
          </label>

          <label className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
            <input
              type="radio"
              name="idvOption"
              value="lowest"
              checked={selectedOption === 'lowest'}
              onChange={(e) => setSelectedOption(e.target.value)}
              className="w-4 h-4 text-blue-500"
            />
            <div className="ml-3">
              <span className="font-medium text-gray-900">Lowest Value</span>
              <p className="text-sm text-gray-500">Minimum coverage with lower premium</p>
            </div>
          </label>

          <label className="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
            <input
              type="radio"
              name="idvOption"
              value="custom"
              checked={selectedOption === 'custom'}
              onChange={(e) => setSelectedOption(e.target.value)}
              className="w-4 h-4 text-blue-500"
            />
            <div className="ml-3 flex-1">
              <span className="font-medium text-gray-900">Set Your Own IDV</span>
              <p className="text-sm text-gray-500">Choose a custom value</p>
              {selectedOption === 'custom' && (
                <input
                  type="number"
                  value={customIdv}
                  onChange={(e) => setCustomIdv(e.target.value)}
                  placeholder="Enter IDV amount"
                  className="mt-2 w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              )}
            </div>
          </label>
        </div>

        <div className="p-4 border-t">
          <button
            onClick={handleSubmit}
            disabled={!selectedOption || (selectedOption === 'custom' && !customIdv)}
            className="w-full bg-[#f94a56] text-white font-medium py-3 px-4 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Recalculate Quote
          </button>
        </div>
      </div>
    </div>
  );
};

export default IdvModal;