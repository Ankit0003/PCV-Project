import { FileText, ChevronRight } from 'lucide-react';

interface OptionItemProps {
  icon: React.ReactNode;
  text: string;
}

const OptionItem = ({ icon, text }: OptionItemProps) => {
  return (
    <button className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors duration-200 rounded-md">
      <div className="flex items-center">
        <span className="text-gray-600 mr-3">{icon}</span>
        <span className="text-gray-800">{text}</span>
      </div>
      <ChevronRight size={20} className="text-gray-400" />
    </button>
  );
};

const OptionsMenu = () => {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
      <div className="p-4 border-b border-gray-100">
        <h2 className="text-lg font-medium text-gray-800">Other options</h2>
      </div>
      
      <div className="divide-y divide-gray-100">
        <OptionItem 
          icon={<FileText size={20} />} 
          text="Request Offline Quotes" 
        />
        <OptionItem 
          icon={<FileText size={20} />} 
          text="Issue Policy with My Quotes" 
        />
        <OptionItem 
          icon={<FileText size={20} />} 
          text="Submit Offline Policy" 
        />
      </div>
    </div>
  );
};

export default OptionsMenu;