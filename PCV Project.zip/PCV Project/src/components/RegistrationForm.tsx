import React, { useState } from 'react';
import { Car } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import PolicyDetailsModal from './PcvFinder/PolicyDetailsModal';

interface RegistrationFormProps {
  regNumber: string;
  setRegNumber: (value: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  onPcvHelp: () => void;
  vehicleDetails?: {
    manufacturer: string;
    model: string;
    manufacturingDate: string;
    registrationDate: string;
    registrationNo: string;
    type: string;
    fuelType: string;
  };
}

const RegistrationForm = ({ 
  regNumber, 
  setRegNumber, 
  onSubmit,
  onPcvHelp,
  vehicleDetails
}: RegistrationFormProps) => {
  const navigate = useNavigate();
  const [showPolicyModal, setShowPolicyModal] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (vehicleDetails) {
      setShowPolicyModal(true);
    } else {
      onSubmit(e);
    }
  };

  const handlePolicyModalClose = () => {
    setShowPolicyModal(false);
  };

  const handlePolicyContinue = (needsInspection: boolean) => {
    setShowPolicyModal(false);
    navigate('/comprehensive-plans');
  };

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <div className="mb-4">
        <div className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100">
          <input
            type="text"
            id="registrationNumber"
            name="registrationNumber"
            placeholder="Registration No"
            value={regNumber}
            onChange={(e) => setRegNumber(e.target.value)}
            className="w-full px-4 py-4 text-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
            required
          />
        </div>
        <button 
          type="button"
          onClick={onPcvHelp}
          className="mt-3 inline-block text-blue-500 text-sm hover:text-blue-700 transition-colors duration-200"
        >
          Don't know your Pcv number?
        </button>
      </div>

      {vehicleDetails && (
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-100 mb-6">
          <div className="flex items-center mb-6">
            <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center mr-4">
              <Car size={24} className="text-blue-500" />
            </div>
            <h3 className="text-lg font-medium text-gray-800">
              {vehicleDetails.manufacturer} {vehicleDetails.model} | {vehicleDetails.type} | {vehicleDetails.fuelType}
            </h3>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div>
              <p className="text-gray-500 text-sm mb-1">Manufacturing Date</p>
              <p className="font-medium">{new Date(vehicleDetails.manufacturingDate).toLocaleDateString()}</p>
            </div>
            <div>
              <p className="text-gray-500 text-sm mb-1">Registration Date</p>
              <p className="font-medium">{new Date(vehicleDetails.registrationDate).toLocaleDateString()}</p>
            </div>
            <div>
              <p className="text-gray-500 text-sm mb-1">Registration No</p>
              <p className="font-medium">{vehicleDetails.registrationNo}</p>
            </div>
          </div>
        </div>
      )}
      
      <button
        type="submit"
        className="w-full bg-[#f94a56] hover:bg-[#e03840] text-white font-medium py-4 px-4 rounded-lg transition-colors duration-200 shadow-sm"
      >
        {vehicleDetails ? 'Confirm & Get Quote' : 'Get Vehicle Details'}
      </button>

      <PolicyDetailsModal
        isOpen={showPolicyModal}
        onClose={handlePolicyModalClose}
        onContinue={handlePolicyContinue}
      />
    </form>
  );
};

export default RegistrationForm;