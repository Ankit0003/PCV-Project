import React, { useState } from 'react';
import { X, Upload } from 'lucide-react';

interface QueryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const QueryModal = ({ isOpen, onClose }: QueryModalProps) => {
  const [formData, setFormData] = useState({
    queryType: '',
    document: null as File | null,
    remarks: ''
  });
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({ ...prev, document: e.target.files![0] }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSuccessModal(true);
  };

  if (!isOpen) return null;

  if (showSuccessModal) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end justify-center sm:items-center z-50">
        <div className="bg-white w-full max-w-md rounded-t-2xl sm:rounded-xl p-6 animate-slide-up">
          <div className="text-center mb-6">
            <h3 className="text-xl font-semibold text-gray-900">Success!</h3>
            <p className="mt-2 text-gray-600">Request raised successfully</p>
          </div>
          <button
            onClick={() => {
              setShowSuccessModal(false);
              onClose();
            }}
            className="w-full bg-[#f94a56] text-white font-medium py-3 px-4 rounded-lg"
          >
            OK
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end justify-center sm:items-center z-50">
      <div className="bg-white w-full max-w-md rounded-t-2xl sm:rounded-xl overflow-hidden animate-slide-up">
        <div className="sticky top-0 bg-white z-10 border-b">
          <div className="flex justify-between items-center p-4">
            <h2 className="text-xl font-semibold text-gray-900">Raise Query</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <X size={24} />
            </button>
          </div>
        </div>

        <div className="max-h-[calc(100vh-200px)] overflow-y-auto">
          <form onSubmit={handleSubmit} className="p-4">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Query Type</label>
                <input
                  type="text"
                  name="queryType"
                  value={formData.queryType}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Upload Document</label>
                <div className="relative border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-500 transition-colors">
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <p className="mt-2 text-sm text-gray-600">
                    {formData.document ? formData.document.name : 'Click to upload or drag and drop'}
                  </p>
                  <input
                    type="file"
                    onChange={handleFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Remarks</label>
                <textarea
                  name="remarks"
                  value={formData.remarks}
                  onChange={handleInputChange}
                  rows={4}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>
          </form>
        </div>

        <div className="sticky bottom-0 bg-white border-t p-4">
          <button
            type="submit"
            onClick={handleSubmit}
            className="w-full bg-[#f94a56] text-white font-medium py-3 px-4 rounded-lg"
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
};

export default QueryModal;