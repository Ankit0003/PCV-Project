import React, { useState } from 'react';
import { X, ChevronDown } from 'lucide-react';

interface SortFilterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApply: (sortOption: string) => void;
}

const SortFilterModal = ({ isOpen, onClose, onApply }: SortFilterModalProps) => {
  const [selectedSort, setSelectedSort] = useState('');
  const [selectedFilters, setSelectedFilters] = useState({
    insurers: [] as string[],
    addOns: [] as string[],
    policyType: '',
    inspectionRequired: false
  });

  const handleApply = () => {
    onApply(selectedSort);
    onClose();
  };

  const handleReset = () => {
    setSelectedSort('');
    setSelectedFilters({
      insurers: [],
      addOns: [],
      policyType: '',
      inspectionRequired: false
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end justify-center z-50">
      <div className="bg-white w-full max-w-md rounded-t-2xl overflow-hidden animate-slide-up max-h-[90vh] flex flex-col">
        <div className="p-4 border-b sticky top-0 bg-white z-10">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-900">Sort & Filter</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
              <X size={24} />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto flex-1">
          {/* Filters Section */}
          <div className="p-4 border-b">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Filters</h3>
            
            {/* Insurers Filter */}
            <div className="mb-6">
              <h4 className="text-sm font-medium text-gray-700 mb-2">Insurers</h4>
              <div className="space-y-2">
                {['United India', 'ICICI Lombard', 'SBI General', 'Bajaj Allianz'].map((insurer) => (
                  <label key={insurer} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={selectedFilters.insurers.includes(insurer)}
                      onChange={(e) => {
                        setSelectedFilters(prev => ({
                          ...prev,
                          insurers: e.target.checked 
                            ? [...prev.insurers, insurer]
                            : prev.insurers.filter(i => i !== insurer)
                        }));
                      }}
                      className="w-4 h-4 text-blue-500 rounded"
                    />
                    <span className="ml-2 text-gray-700">{insurer}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Add-ons Filter */}
            <div className="mb-6">
              <h4 className="text-sm font-medium text-gray-700 mb-2">Add-ons</h4>
              <div className="space-y-2">
                {[
                  'Zero Depreciation',
                  'Engine Protection',
                  'NCB Protection',
                  'Return to Invoice',
                  'Roadside Assistance'
                ].map((addon) => (
                  <label key={addon} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={selectedFilters.addOns.includes(addon)}
                      onChange={(e) => {
                        setSelectedFilters(prev => ({
                          ...prev,
                          addOns: e.target.checked 
                            ? [...prev.addOns, addon]
                            : prev.addOns.filter(a => a !== addon)
                        }));
                      }}
                      className="w-4 h-4 text-blue-500 rounded"
                    />
                    <span className="ml-2 text-gray-700">{addon}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Policy Type Filter */}
            <div className="mb-6">
              <h4 className="text-sm font-medium text-gray-700 mb-2">Policy Type</h4>
              <div className="space-y-2">
                {['Comprehensive', 'Third Party'].map((type) => (
                  <label key={type} className="flex items-center">
                    <input
                      type="radio"
                      name="policyType"
                      checked={selectedFilters.policyType === type}
                      onChange={() => {
                        setSelectedFilters(prev => ({
                          ...prev,
                          policyType: type
                        }));
                      }}
                      className="w-4 h-4 text-blue-500"
                    />
                    <span className="ml-2 text-gray-700">{type}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Inspection Required Filter */}
            <div className="mb-6">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={selectedFilters.inspectionRequired}
                  onChange={(e) => {
                    setSelectedFilters(prev => ({
                      ...prev,
                      inspectionRequired: e.target.checked
                    }));
                  }}
                  className="w-4 h-4 text-blue-500 rounded"
                />
                <span className="ml-2 text-gray-700">Inspection Required</span>
              </label>
            </div>
          </div>

          {/* Sort Section */}
          <div className="p-4">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Sort</h3>
            <div className="space-y-3">
              {[
                { value: 'premium-low-high', label: 'Low to high premium' },
                { value: 'premium-high-low', label: 'High to low premium' },
                { value: 'discount-low-high', label: 'Low to high discount' },
                { value: 'discount-high-low', label: 'High to low discount' },
                { value: 'arp-low-high', label: 'Low to high ARP' },
                { value: 'arp-high-low', label: 'High to low ARP' },
                { value: 'idv-low-high', label: 'Low to high IDV' },
                { value: 'idv-high-low', label: 'High to low IDV' },
              ].map((option) => (
                <label key={option.value} className="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                  <input
                    type="radio"
                    name="sortOption"
                    value={option.value}
                    checked={selectedSort === option.value}
                    onChange={(e) => setSelectedSort(e.target.value)}
                    className="w-4 h-4 text-blue-500"
                  />
                  <span className="ml-3 text-gray-700">{option.label}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        <div className="p-4 border-t sticky bottom-0 bg-white">
          <div className="flex space-x-4">
            <button
              onClick={handleReset}
              className="flex-1 py-3 px-4 rounded-lg border border-gray-300 text-gray-700 font-medium"
            >
              Reset filters
            </button>
            <button
              onClick={handleApply}
              className="flex-1 bg-[#f94a56] text-white font-medium py-3 px-4 rounded-lg"
            >
              Apply
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SortFilterModal;