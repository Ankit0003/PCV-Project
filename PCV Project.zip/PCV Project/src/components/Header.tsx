import { ChevronLeft } from 'lucide-react';

interface HeaderProps {
  title: string;
  onBack?: () => void;
}

const Header = ({ title, onBack }: HeaderProps) => {
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
      <div className="container mx-auto max-w-md px-4 py-4 flex items-center">
        <button 
          className="p-1 mr-4 rounded-full hover:bg-gray-100 transition-colors duration-200"
          aria-label="Go back"
          onClick={onBack}
        >
          <ChevronLeft size={24} className="text-gray-700" />
        </button>
        <h1 className="text-xl font-semibold text-gray-800">{title}</h1>
      </div>
    </header>
  );
};

export default Header;