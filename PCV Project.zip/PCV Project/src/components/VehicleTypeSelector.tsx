import React from 'react';

interface VehicleTypeSelectorProps {
  selectedType: 'renew' | 'new';
  onTypeChange: (type: 'renew' | 'new') => void;
}

const VehicleTypeSelector = ({ selectedType, onTypeChange }: VehicleTypeSelectorProps) => {
  return (
    <div className="bg-white p-1 rounded-lg shadow-sm border border-gray-100 mb-6 flex">
      <button
        onClick={() => onTypeChange('renew')}
        className={`flex-1 py-3 px-4 rounded-md text-sm font-medium transition-colors duration-200 ${
          selectedType === 'renew'
            ? 'bg-blue-50 text-blue-600'
            : 'text-gray-600 hover:bg-gray-50'
        }`}
      >
        Renew/Expired
      </button>
      <button
        onClick={() => onTypeChange('new')}
        className={`flex-1 py-3 px-4 rounded-md text-sm font-medium transition-colors duration-200 ${
          selectedType === 'new'
            ? 'bg-blue-50 text-blue-600'
            : 'text-gray-600 hover:bg-gray-50'
        }`}
      >
        New Vehicle
      </button>
    </div>
  );
};

export default VehicleTypeSelector;