import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface NewVehicleFormProps {
  onSubmit: (e: React.FormEvent) => void;
  formData?: {
    vehicleType: string;
    manufacturer: string;
    model: string;
    fuelType: string;
    variant: string;
    registrationYear: string;
    rto: string;
  };
  onVehicleTypeClick: () => void;
}

const NewVehicleForm = ({ onSubmit, formData, onVehicleTypeClick }: NewVehicleFormProps) => {
  const navigate = useNavigate();
  const [localFormData, setLocalFormData] = useState(formData || {
    vehicleType: '',
    manufacturer: '',
    model: '',
    fuelType: '',
    variant: '',
    registrationYear: '',
    rto: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setLocalFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/vehicle-details', { 
      state: { 
        vehicleDetails: {
          manufacturer: localFormData.manufacturer,
          model: localFormData.model,
          manufacturingDate: "2024-01-01", // Default for new vehicle
          registrationDate: "2024-01-01", // Default for new vehicle
          type: localFormData.vehicleType,
          fuelType: localFormData.fuelType,
          variant: localFormData.variant
        }
      }
    });
  };

  return (
    <form onSubmit={handleSubmit} className="w-full space-y-4">
      <div className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100">
        <input
          type="text"
          name="vehicleType"
          placeholder="Vehicle Type"
          value={localFormData.vehicleType}
          onChange={handleChange}
          onClick={onVehicleTypeClick}
          className="w-full px-4 py-4 text-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          readOnly
          required
        />
      </div>

      <div className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100">
        <input
          type="text"
          name="manufacturer"
          placeholder="Manufacturer"
          value={localFormData.manufacturer}
          onChange={handleChange}
          className="w-full px-4 py-4 text-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          readOnly
          required
        />
      </div>

      <div className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100">
        <input
          type="text"
          name="model"
          placeholder="Model"
          value={localFormData.model}
          onChange={handleChange}
          className="w-full px-4 py-4 text-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          readOnly
          required
        />
      </div>

      <div className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100">
        <input
          type="text"
          name="fuelType"
          placeholder="Fuel Type"
          value={localFormData.fuelType}
          onChange={handleChange}
          className="w-full px-4 py-4 text-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          readOnly
          required
        />
      </div>

      <div className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100">
        <input
          type="text"
          name="variant"
          placeholder="Variant"
          value={localFormData.variant}
          onChange={handleChange}
          className="w-full px-4 py-4 text-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          readOnly
          required
        />
      </div>

      <div className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100">
        <input
          type="text"
          name="registrationYear"
          placeholder="Registration Year"
          value={localFormData.registrationYear}
          onChange={handleChange}
          className="w-full px-4 py-4 text-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          readOnly
          required
        />
      </div>

      <div className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100">
        <input
          type="text"
          name="rto"
          placeholder="RTO/City"
          value={localFormData.rto}
          onChange={handleChange}
          className="w-full px-4 py-4 text-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          readOnly
          required
        />
      </div>

      <button
        type="submit"
        className="w-full bg-[#f94a56] hover:bg-[#e03840] text-white font-medium py-4 px-4 rounded-lg transition-colors duration-200 shadow-sm mt-6"
      >
        Get Quote
      </button>
    </form>
  );
};

export default NewVehicleForm;