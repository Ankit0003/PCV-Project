import React, { useState } from 'react';

interface Question {
  id: string;
  text: string;
  options: { value: string; label: string; }[];
}

interface FormData {
  [key: string]: string;
}

const questions: Question[] = [
  {
    id: 'drivingFrequency',
    text: 'How often do you drive your vehicle?',
    options: [
      { value: 'daily', label: 'Daily commute' },
      { value: 'weekend', label: 'Weekend only' },
      { value: 'occasional', label: 'Occasional use' }
    ]
  },
  {
    id: 'drivingArea',
    text: 'What kind of areas do you usually drive?',
    options: [
      { value: 'city', label: 'City traffic' },
      { value: 'highway', label: 'Highways' },
      { value: 'rural', label: 'Rural or semi urban areas' }
    ]
  },
  {
    id: 'longDistance',
    text: 'Do you often travel long distances or out of town?',
    options: [
      { value: 'frequently', label: 'Yes, frequently' },
      { value: 'occasionally', label: 'Occasionally' },
      { value: 'rarely', label: 'Rarely or never' }
    ]
  },
  {
    id: 'floodProne',
    text: 'Do you live in area prone to flooding?',
    options: [
      { value: 'yes', label: 'Yes' },
      { value: 'no', label: 'No' }
    ]
  },
  {
    id: 'parking',
    text: 'Is your vehicle parked in secured/covered location?',
    options: [
      { value: 'garage', label: 'Yes, in a garage' },
      { value: 'outside', label: 'No, parked outside' }
    ]
  },
  {
    id: 'longTerm',
    text: 'Do you want to keep this vehicle for more than 3 years?',
    options: [
      { value: 'yes', label: 'Yes' },
      { value: 'no', label: 'No' }
    ]
  }
];

interface Recommendation {
  addon: string;
  description: string;
  recommended: boolean;
}

const QuestionnaireForm = () => {
  const [formData, setFormData] = useState<FormData>({});
  const [showRecommendations, setShowRecommendations] = useState(false);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);

  const handleOptionSelect = (questionId: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [questionId]: value
    }));
  };

  const generateRecommendations = (data: FormData): Recommendation[] => {
    const recommendations: Recommendation[] = [
      {
        addon: 'Zero Depreciation Cover',
        description: 'Covers the depreciation cost of your vehicle parts during claims',
        recommended: data.drivingFrequency === 'daily' || data.drivingArea === 'city'
      },
      {
        addon: 'Engine Protection Cover',
        description: 'Covers damage to engine due to water ingression',
        recommended: data.floodProne === 'yes'
      },
      {
        addon: 'Personal Accident Cover',
        description: 'Provides coverage against accidental injuries',
        recommended: data.drivingFrequency === 'daily' || data.longDistance === 'frequently'
      },
      {
        addon: 'Electrical Accessories Cover',
        description: 'Covers damage to electrical components',
        recommended: true
      },
      {
        addon: 'Return to Invoice',
        description: 'Covers the difference between invoice value and IDV',
        recommended: data.longTerm === 'yes'
      }
    ];

    return recommendations;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newRecommendations = generateRecommendations(formData);
    setRecommendations(newRecommendations);
    setShowRecommendations(true);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-semibold text-gray-800 mb-6">
        Help us find the best policy for you
      </h1>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {questions.map((question) => (
          <div key={question.id} className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
            <p className="text-lg text-gray-800 mb-4">{question.text}</p>
            <div className="space-y-3">
              {question.options.map((option) => (
                <label key={option.value} className="flex items-center">
                  <input
                    type="radio"
                    name={question.id}
                    value={option.value}
                    checked={formData[question.id] === option.value}
                    onChange={() => handleOptionSelect(question.id, option.value)}
                    className="w-4 h-4 text-blue-500 border-gray-300 focus:ring-blue-500"
                    required
                  />
                  <span className="ml-3 text-gray-700">{option.label}</span>
                </label>
              ))}
            </div>
          </div>
        ))}

        <button
          type="submit"
          className="w-full bg-blue-500 text-white font-medium py-3 px-4 rounded-lg hover:bg-blue-600 transition-colors duration-200"
        >
          Submit
        </button>
      </form>

      {showRecommendations && (
        <div className="mt-8 space-y-4">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">
            Recommended Add-ons
          </h2>
          
          {recommendations.map((rec, index) => (
            <div 
              key={index}
              className={`p-4 rounded-lg border ${
                rec.recommended 
                  ? 'bg-green-50 border-green-200' 
                  : 'bg-gray-50 border-gray-200'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-medium text-gray-800">{rec.addon}</h3>
                  <p className="text-sm text-gray-600 mt-1">{rec.description}</p>
                </div>
                {rec.recommended && (
                  <span className="px-2 py-1 bg-green-100 text-green-800 text-sm font-medium rounded">
                    Recommended
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default QuestionnaireForm;