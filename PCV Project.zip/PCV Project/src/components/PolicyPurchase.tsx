import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import Header from './Header';
import { Info, X } from 'lucide-react';

interface PolicyPurchaseProps {
  onBack?: () => void;
}

const PolicyPurchase = ({ onBack }: PolicyPurchaseProps) => {
  const location = useLocation();
  const [showInformModal, setShowInformModal] = useState(false);
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  
  const vehicleDetails = {
    name: "Maruti Alto 800 2016-2019",
    city: "City",
    mfgYear: "01 May, 2021",
    registrationDate: "02 May, 2021",
    prevNcb: "0%",
    insuranceCompany: "United India",
    premium: "3,812"
  };

  const handlePremiumClick = () => {
    setShowInformModal(true);
  };

  const handleInform = () => {
    setShowInformModal(false);
    setShowNotificationModal(true);
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#f0f7fa]">
      <Header title="Purchase Policy" onBack={onBack} />
      
      <main className="flex-1 container mx-auto max-w-md px-4 py-6">
        <div className="bg-white rounded-lg p-6 shadow-sm">
          <div className="space-y-6">
            <div>
              <h2 className="text-gray-600 mb-2">Vehicle</h2>
              <h3 className="text-xl font-medium text-gray-900">{vehicleDetails.name}-{vehicleDetails.city}</h3>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <h2 className="text-gray-600 mb-2">Mfg Year</h2>
                <p className="text-lg text-gray-900">{vehicleDetails.mfgYear}</p>
              </div>
              <div>
                <h2 className="text-gray-600 mb-2">Registration Date</h2>
                <p className="text-lg text-gray-900">{vehicleDetails.registrationDate}</p>
              </div>
            </div>

            <div>
              <h2 className="text-gray-600 mb-2">Prev. NCB</h2>
              <p className="text-lg text-gray-900">{vehicleDetails.prevNcb}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg mt-6 overflow-hidden shadow-sm">
          <div className="p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-amber-50 px-3 py-1 rounded-full flex items-center space-x-2">
                <span className="text-amber-800 text-sm">Self Inspection</span>
                <Info size={16} className="text-amber-800" />
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center text-white text-xs">
                LOGO
              </div>
              <div>
                <h3 className="text-xl font-medium text-gray-900">{vehicleDetails.insuranceCompany}</h3>
                <div className="mt-1 inline-block bg-gray-100 px-3 py-1 rounded">
                  <span className="text-gray-900">₹ {vehicleDetails.premium}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-100 p-4">
            <div className="flex items-center justify-between">
              <button className="text-gray-700 font-medium">
                View Benefits & Breakup
              </button>
              <button 
                onClick={handlePremiumClick}
                className="bg-[#f94a56] text-white px-6 py-2 rounded-lg flex items-center space-x-2"
              >
                <span>₹ {vehicleDetails.premium}</span>
                <span className="text-xl">›</span>
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Inform Agent Modal */}
      {showInformModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-sm">
            <div className="p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Inform the agent?</h3>
              
              <div className="flex space-x-4">
                <button
                  onClick={() => setShowInformModal(false)}
                  className="flex-1 py-2 px-4 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleInform}
                  className="flex-1 py-2 px-4 bg-[#f94a56] text-white rounded-lg font-medium hover:bg-[#e03840]"
                >
                  Inform
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Notification Sent Modal */}
      {showNotificationModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-sm">
            <div className="p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">
                Notification sent to agent
              </h3>
              
              <button
                onClick={() => setShowNotificationModal(false)}
                className="w-full py-2 px-4 bg-[#f94a56] text-white rounded-lg font-medium hover:bg-[#e03840]"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PolicyPurchase;