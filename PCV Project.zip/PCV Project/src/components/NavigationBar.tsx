import { Home, Circle, Square } from 'lucide-react';

const NavigationBar = () => {
  return (
    <nav className="bg-white border-t border-gray-200 py-3 sticky bottom-0 w-full">
      <div className="container mx-auto max-w-md flex justify-around items-center">
        <button 
          className="p-2 text-gray-500 hover:text-gray-800 transition-colors duration-200"
          aria-label="Home"
        >
          <Square size={24} />
        </button>
        
        <button 
          className="p-2 text-gray-800 transition-colors duration-200"
          aria-label="Menu"
        >
          <Circle size={24} />
        </button>
        
        <button 
          className="p-2 text-gray-500 hover:text-gray-800 transition-colors duration-200"
          aria-label="Documents"
        >
          <div className="transform rotate-180">
            <Square size={24} className="transform -rotate-45" />
          </div>
        </button>
      </div>
    </nav>
  );
};

export default NavigationBar;