import React from 'react';
import { ChevronLeft, Shield, Check } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Plan {
  name: string;
  price: number;
  features: string[];
  recommended?: boolean;
}

const ComprehensivePlans = () => {
  const navigate = useNavigate();

  const plans: Plan[] = [
    {
      name: 'Basic',
      price: 3999,
      features: [
        'Third-party liability cover',
        'Own damage cover',
        'Personal accident cover',
        '24/7 roadside assistance'
      ]
    },
    {
      name: 'Premium',
      price: 5999,
      features: [
        'All Basic features',
        'Zero depreciation cover',
        'Engine protection',
        'NCB protection',
        'Return to invoice'
      ],
      recommended: true
    },
    {
      name: 'Ultimate',
      price: 7999,
      features: [
        'All Premium features',
        'Key replacement cover',
        'Consumables cover',
        'Daily allowance',
        'Tire protection'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="container mx-auto max-w-3xl px-4">
          <div className="flex items-center h-16">
            <button 
              onClick={() => navigate(-1)}
              className="p-2 rounded-full hover:bg-gray-100 mr-3"
            >
              <ChevronLeft size={24} className="text-gray-700" />
            </button>
            <h1 className="text-xl font-semibold text-gray-800">Choose Your Plan</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto max-w-3xl px-4 py-8">
        <div className="grid gap-6 md:grid-cols-3">
          {plans.map((plan) => (
            <div 
              key={plan.name}
              className={`bg-white rounded-xl shadow-sm border ${
                plan.recommended ? 'border-blue-500' : 'border-gray-200'
              } overflow-hidden`}
            >
              {plan.recommended && (
                <div className="bg-blue-500 text-white text-center py-2 text-sm font-medium">
                  Recommended
                </div>
              )}
              
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800">{plan.name}</h3>
                    <div className="mt-1 flex items-center">
                      <span className="text-2xl font-bold">₹{plan.price}</span>
                      <span className="text-gray-500 ml-1">/year</span>
                    </div>
                  </div>
                  <Shield size={24} className="text-blue-500" />
                </div>

                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <Check size={20} className="text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button className={`w-full py-3 px-4 rounded-lg font-medium ${
                  plan.recommended
                    ? 'bg-blue-500 text-white hover:bg-blue-600'
                    : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                } transition-colors duration-200`}>
                  Select Plan
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default ComprehensivePlans;