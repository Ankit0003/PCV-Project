import React, { useState } from 'react';
import { Car, X } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import Header from './Header';
import NavigationBar from './NavigationBar';
import PolicyDetailsModal from './PcvFinder/PolicyDetailsModal';

interface VehicleDetailsProps {
  onBack?: () => void;
}

const VehicleDetails = ({ onBack }: VehicleDetailsProps) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [showPolicyModal, setShowPolicyModal] = useState(false);
  
  const { vehicleDetails } = location.state || {
    vehicleDetails: {
      manufacturer: "Bajaj",
      model: "RE Compact",
      manufacturingDate: "2004-01-01",
      registrationDate: "2004-05-10",
      registrationNo: "MH43C4132",
      type: "2000/CNG",
      fuelType: "CNG"
    }
  };

  const handleConfirmAndGetQuote = () => {
    setShowPolicyModal(true);
  };

  const handlePolicyModalClose = () => {
    setShowPolicyModal(false);
  };

  const handlePolicyContinue = (needsInspection: boolean) => {
    setShowPolicyModal(false);
    navigate('/comprehensive-plans');
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#f0f7fa]">
      <Header title="PCV Insurance" onBack={() => navigate('/')} />
      
      <main className="flex-1 container mx-auto max-w-md px-4 py-6">
        <div className="bg-white rounded-lg p-4 mb-4 relative flex items-center justify-between shadow-sm border border-gray-100">
          <span className="text-gray-600">Registration No</span>
          <div className="flex items-center">
            <span className="mr-3 font-medium">{vehicleDetails.registrationNo}</span>
            <button
              onClick={() => navigate('/')}
              className="text-gray-400 hover:text-gray-600 transition-colors"
              aria-label="Clear registration number"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-medium text-gray-800">Is this your vehicle?</h2>
          <button className="text-blue-500 text-sm">Edit Details</button>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-100 mb-6">
          <div className="flex items-center mb-6">
            <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center mr-4">
              <Car size={24} className="text-blue-500" />
            </div>
            <h3 className="text-lg font-medium text-gray-800">
              {vehicleDetails.manufacturer} {vehicleDetails.model} | {vehicleDetails.type} | {vehicleDetails.fuelType}
            </h3>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div>
              <p className="text-gray-500 text-sm mb-1">Manufacturing Date</p>
              <p className="font-medium">{vehicleDetails.manufacturingDate}</p>
            </div>
            <div>
              <p className="text-gray-500 text-sm mb-1">Registration Date</p>
              <p className="font-medium">{vehicleDetails.registrationDate}</p>
            </div>
            <div>
              <p className="text-gray-500 text-sm mb-1">Registration No</p>
              <p className="font-medium">{vehicleDetails.registrationNo}</p>
            </div>
          </div>
        </div>

        <button
          onClick={handleConfirmAndGetQuote}
          className="w-full bg-[#f94a56] hover:bg-[#e03840] text-white font-medium py-4 px-4 rounded-lg transition-colors duration-200 shadow-sm"
        >
          Confirm & Get Quote
        </button>
      </main>

      <NavigationBar />

      <PolicyDetailsModal
        isOpen={showPolicyModal}
        onClose={handlePolicyModalClose}
        onContinue={handlePolicyContinue}
      />
    </div>
  );
};

export default VehicleDetails;